package com.example.imc_app

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtPeso = findViewById<EditText>(R.id.edtPeso)
        val edtAltura = findViewById<EditText>(R.id.edtAltura)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val tvResultado = findViewById<TextView>(R.id.tvResultado)

        btnCalcular.setOnClickListener {
            // Obter os valores de peso e altura inseridos
            val pesoString = edtPeso.text.toString().trim()
            val alturaString = edtAltura.text.toString().trim()

            // Verifica se os campos não estão vazios
            if (pesoString.isNotEmpty() && alturaString.isNotEmpty()) {
                // Converte os valores para Double
                val peso = pesoString.toDoubleOrNull()
                val altura = alturaString.toDoubleOrNull()

                if (peso != null && altura != null && altura > 0) {
                    // Calcular o IMC
                    val imc = peso / (altura * altura)
                    tvResultado.text = "IMC: %.2f".format(imc)

                    // Exibir mensagem de classificação do IMC
                    when {
                        imc < 18.5 -> tvResultado.append("\nAbaixo do peso")
                        imc in 18.5..24.9 -> tvResultado.append("\nPeso normal")
                        imc in 25.0..29.9 -> tvResultado.append("\nSobrepeso")
                        imc >= 30 -> tvResultado.append("\nObesidade")
                    }
                } else {
                    // tratamento de erros
                    Toast.makeText(this, "Por favor, insira valores numéricos válidos para peso e altura", Toast.LENGTH_SHORT).show()
                }
            } else {
                // tratamento de erro caso não for inserido valores
                Toast.makeText(this, "Por favor, insira peso e altura", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
